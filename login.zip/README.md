# BudgetBuddy

BudgetBuddy is a lightweight budgeting web app built with static HTML, CSS, and JavaScript.

## What is included
- Landing page (`index.html`)
- Login and registration flow
- Dashboard with charts and quick actions
- Transactions, Wallet, Goals, Reports, AI assistant, and Settings pages
- LocalStorage persistence for user data, transactions, and theme
- PDF export and chart visualization
- PWA manifest and service worker support

## Demo
- App entry: `index.html`
- Demo video: [Add your demo video link here]

## Notes
- Open `index.html` in a browser to use the app.
- Login with the account created on `register.html`.
